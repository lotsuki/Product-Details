/* eslint-disable import/no-extraneous-dependencies */

const faker = require("faker");
const Product = require("./Product.js");
const db = require("./index.js");

db.dropCollection("products", () => {});

var capitalizeFirst = str => {
  var capitalized = str[0].toUpperCase();
  for (var i = 1; i < str.length; i++) {
    if (str[i - 1] === ' ') { capitalized += str[i].toUpperCase(); }
    else { capitalized += str[i] }
  }
  return capitalized;
};

var randomNum = () => Math.floor(Math.random() * Math.floor(100));

const populateImages = index => {
  var images = [{
    image: `https://s3-us-west-1.amazonaws.com/hrr34-trailblazer/${index}-min.jpg`,
    color: capitalizeFirst(faker.commerce.color())
  }];
  var numOfImages;

  for (var i = 4; i > 0; i--) {
    if (index % i === 0) {
      numOfImages = i - 1;
      break;
    }
  }
  for (var i = 1; i <= numOfImages; i++) {
    images.push({
      image:`https://s3-us-west-1.amazonaws.com/hrr34-trailblazer/${randomNum()}-min.jpg`,
      color: capitalizeFirst(faker.commerce.color())
    })
  }
  return images;
};

const createMockProducts = () => {
  const products = [];
  for (let i = 1; i <= 100; i += 1) {
    products.push({
      _id: i,
      name: faker.commerce.productName(),
      rating: Number(faker.finance.amount(1, 5, 1)),
      reviewCount: faker.random.number({ min: 20, max: 150 }),
      itemNum: i,
      price: faker.commerce.price(50, 500),
      mainImage: `https://s3-us-west-1.amazonaws.com/hrr34-trailblazer/${i}-min.jpg`,
      images: populateImages(i)
    });
  }
  return products;
};

const data = createMockProducts();

function inputSampleProducts() {
  return Product.create(data)
    .then(() => db.close())
    .catch(err => console.log("err", err));
};

inputSampleProducts();

module.exports.createMockProducts = createMockProducts;

// var createMockReviews = () => {
//   var reviews = [];
//   var randomNumber = faker.random.number({min: 3, max: 16});

//    for (var i = 1; i < randomNumber; i++) {
//      reviews.push({
//        review_id: faker.random.number({ max: 5, min: 1 }),
//        reviewer: faker.internet.userName(),
//        title: faker.lorem.sentence(),
//        body: faker.lorem.paragraph(5),
//        recomend: faker.random.boolean(),
//        helpful: faker.random.number(47),
//        unhelpful: faker.random.number(22)
//      });
//    }
//    return reviews;
// };
